package principal.principal.insight;

import br.com.camada.view.TelaLogin;

public class Insight {

    public static void main(String[] args) {
        // Criar e exibir a tela de login
        TelaLogin telaLogin = new TelaLogin();
        telaLogin.setVisible(true);
    }
}