
package br.com.camada.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaDeCadastro extends javax.swing.JFrame {

    /**
     * Creates new form TelaDeCadastro
     */
    public TelaDeCadastro() {
        initComponents();
        btn_avancar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                realizarCadastro();
            }
        });
        // Defina o tamanho padrão da janela
        setSize(420, 430);
        
        // Centralize a janela na tela
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_nome = new javax.swing.JLabel();
        txt_email = new javax.swing.JTextField();
        lbl_senha = new javax.swing.JLabel();
        txt_nome_completo = new javax.swing.JTextField();
        lbl_telefone = new javax.swing.JLabel();
        txt_telefone = new javax.swing.JTextField();
        ckx_ensino_medio = new javax.swing.JCheckBox();
        ckx_fund1 = new javax.swing.JCheckBox();
        ckx_fund2 = new javax.swing.JCheckBox();
        lbl_email = new javax.swing.JLabel();
        txt_senha = new javax.swing.JPasswordField();
        btn_avancar = new javax.swing.JButton();
        lbl_cadastro = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lbl_nome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_nome.setText("Nome Completo");
        getContentPane().add(lbl_nome);
        lbl_nome.setBounds(10, 110, 180, 40);

        txt_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_emailActionPerformed(evt);
            }
        });
        getContentPane().add(txt_email);
        txt_email.setBounds(210, 150, 180, 30);

        lbl_senha.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_senha.setText("Senha");
        getContentPane().add(lbl_senha);
        lbl_senha.setBounds(210, 190, 180, 40);

        txt_nome_completo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nome_completoActionPerformed(evt);
            }
        });
        getContentPane().add(txt_nome_completo);
        txt_nome_completo.setBounds(10, 150, 180, 30);

        lbl_telefone.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_telefone.setText("Telefone");
        getContentPane().add(lbl_telefone);
        lbl_telefone.setBounds(10, 190, 180, 40);

        txt_telefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_telefoneActionPerformed(evt);
            }
        });
        getContentPane().add(txt_telefone);
        txt_telefone.setBounds(10, 230, 180, 30);

        ckx_ensino_medio.setText("Ensino medio");
        getContentPane().add(ckx_ensino_medio);
        ckx_ensino_medio.setBounds(10, 340, 140, 30);

        ckx_fund1.setText("Fundamental l");
        getContentPane().add(ckx_fund1);
        ckx_fund1.setBounds(10, 280, 140, 30);

        ckx_fund2.setText("Fundamental ll");
        getContentPane().add(ckx_fund2);
        ckx_fund2.setBounds(10, 310, 140, 30);

        lbl_email.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_email.setText("Email");
        getContentPane().add(lbl_email);
        lbl_email.setBounds(210, 110, 180, 40);
        getContentPane().add(txt_senha);
        txt_senha.setBounds(210, 230, 180, 30);

        btn_avancar.setText("Avancar");
        btn_avancar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(btn_avancar);
        btn_avancar.setBounds(283, 345, 110, 40);

        lbl_cadastro.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_cadastro.setText("Cadastro");
        lbl_cadastro.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(lbl_cadastro);
        lbl_cadastro.setBounds(10, 10, 390, 100);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailActionPerformed

    private void txt_nome_completoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nome_completoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nome_completoActionPerformed

    private void txt_telefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_telefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_telefoneActionPerformed

     private void realizarCadastro() {
        // Obtém os dados dos campos
        String nome = txt_nome_completo.getText();
        String email = txt_email.getText();
        String telefone = txt_telefone.getText();
        String senha = new String(txt_senha.getPassword());

        // Verifica se algum campo está vazio
        if (nome.isEmpty() || email.isEmpty() || telefone.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insira aqui o código para inserir os dados no banco de dados

        // Limpa os campos
        txt_nome_completo.setText("");
        txt_email.setText("");
        txt_telefone.setText("");
        txt_senha.setText("");

        // Vai para a tela de login
        System.out.println("Aqui estamos antes de abrir a TelaDeLogin");
    TelaLogin telaLogin = new TelaLogin();
    telaLogin.setVisible(true);
    this.dispose(); // Fecha a tela atual
    System.out.println("Aqui estamos depois de abrir a TelaDeLogin");
}

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaDeCadastro().setVisible(true);
            }
        });
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_avancar;
    private javax.swing.JCheckBox ckx_ensino_medio;
    private javax.swing.JCheckBox ckx_fund1;
    private javax.swing.JCheckBox ckx_fund2;
    private javax.swing.JLabel lbl_cadastro;
    private javax.swing.JLabel lbl_email;
    private javax.swing.JLabel lbl_nome;
    private javax.swing.JLabel lbl_senha;
    private javax.swing.JLabel lbl_telefone;
    private javax.swing.JTextField txt_email;
    private javax.swing.JTextField txt_nome_completo;
    private javax.swing.JPasswordField txt_senha;
    private javax.swing.JTextField txt_telefone;
    // End of variables declaration//GEN-END:variables
}
