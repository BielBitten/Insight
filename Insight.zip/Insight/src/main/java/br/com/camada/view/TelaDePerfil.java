
package br.com.camada.view;
/**
 *
 * @author gabri
 */
public class TelaDePerfil extends javax.swing.JFrame {

    
    
    public TelaDePerfil() {
        initComponents();       
        setSize(400, 350);
                // Centralize a janela na tela
        setLocationRelativeTo(null);
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_perfil = new javax.swing.JLabel();
        lbl_aparecerNome = new javax.swing.JLabel();
        lbl_nome = new javax.swing.JLabel();
        lbl_email = new javax.swing.JLabel();
        lbl_aparecerEmail = new javax.swing.JLabel();
        lbl_telefone = new javax.swing.JLabel();
        lbl_aparecerTelefone = new javax.swing.JLabel();
        btn_voltar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lbl_perfil.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_perfil.setText("Perfil");
        lbl_perfil.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(lbl_perfil);
        lbl_perfil.setBounds(12, 12, 376, 45);

        lbl_aparecerNome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_aparecerNome.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(lbl_aparecerNome);
        lbl_aparecerNome.setBounds(10, 110, 170, 30);

        lbl_nome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_nome.setText("Nome");
        lbl_nome.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(lbl_nome);
        lbl_nome.setBounds(10, 70, 170, 30);

        lbl_email.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_email.setText("Email");
        lbl_email.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(lbl_email);
        lbl_email.setBounds(210, 70, 180, 30);

        lbl_aparecerEmail.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_aparecerEmail.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(lbl_aparecerEmail);
        lbl_aparecerEmail.setBounds(210, 110, 180, 30);

        lbl_telefone.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_telefone.setText("Telefone");
        lbl_telefone.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(lbl_telefone);
        lbl_telefone.setBounds(10, 150, 170, 30);

        lbl_aparecerTelefone.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_aparecerTelefone.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(lbl_aparecerTelefone);
        lbl_aparecerTelefone.setBounds(10, 190, 170, 30);

        btn_voltar.setText("Voltar");
        btn_voltar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_voltarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_voltar);
        btn_voltar.setBounds(10, 250, 110, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_voltarActionPerformed
        
    TelaDeMenu telaMenu = new TelaDeMenu();
    telaMenu.setVisible(true);

    this.dispose();
    }//GEN-LAST:event_btn_voltarActionPerformed

    /**
     * @param args the command line arguments
     */
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_voltar;
    private javax.swing.JLabel lbl_aparecerEmail;
    private javax.swing.JLabel lbl_aparecerNome;
    private javax.swing.JLabel lbl_aparecerTelefone;
    private javax.swing.JLabel lbl_email;
    private javax.swing.JLabel lbl_nome;
    private javax.swing.JLabel lbl_perfil;
    private javax.swing.JLabel lbl_telefone;
    // End of variables declaration//GEN-END:variables
}
