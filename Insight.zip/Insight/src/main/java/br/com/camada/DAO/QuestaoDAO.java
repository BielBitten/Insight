package br.com.camada.dao;

import br.com.camada.jdbc.ConnectFactory;
import br.com.camada.controller.Questao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class QuestaoDAO {

    public List<Questao> obterQuestoesPorMateria(int idMateria) {
        List<Questao> questoes = new ArrayList<>();

        try (Connection conexao = ConnectFactory.obterConexao()) {
            String sql = "jdbc:mysql://localhost:3306/bd_insight";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, idMateria);

                try (ResultSet resultado = stmt.executeQuery()) {
                    while (resultado.next()) {
                        Questao questao = mapearQuestao(resultado);
                        questoes.add(questao);
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao obter questões por matéria", e);
        }

        return questoes;
    }

    private Questao mapearQuestao(ResultSet resultado) throws SQLException {
        Questao questao = new Questao();
        questao.setId_pergunta(resultado.getInt("id_questao"));
        questao.setId_materia(resultado.getInt("id_materia"));
        questao.setTexto_pergunta(resultado.getString("pergunta"));
        questao.setResposta_1(resultado.getString("resposta1"));
        questao.setResposta_2(resultado.getString("resposta2"));
        questao.setResposta_3(resultado.getString("resposta3"));
        questao.setResposta_4(resultado.getString("resposta4"));
        questao.setResposta_5(resultado.getString("resposta5"));

        return questao;
    }

public Questao obterProximaQuestao(int idMateria, List<Integer> questoesRespondidas) {
    List<Questao> questoesNaoRespondidas = obterQuestoesNaoRespondidas(idMateria, questoesRespondidas);

    if (!questoesNaoRespondidas.isEmpty()) {
        return questoesNaoRespondidas.get(0);
    }

    return null;
}

    private List<Questao> obterQuestoesNaoRespondidas(int idMateria, List<Integer> questoesRespondidas) {
        List<Questao> todasQuestoes = obterQuestoesPorMateria(idMateria);
        List<Questao> naoRespondidas = new ArrayList<>();

        for (Questao questao : todasQuestoes) {
            if (!questoesRespondidas.contains(questao.getId_pergunta())) {
                naoRespondidas.add(questao);
            }
        }

        return naoRespondidas;
    }
}


