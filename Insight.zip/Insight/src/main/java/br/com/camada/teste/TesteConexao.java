package br.com.camada.teste;

import br.com.camada.jdbc.ConnectFactory;
import java.sql.Connection;

public class TesteConexao {

    public static void main(String[] args) {
        try (Connection conexao = ConnectFactory.obterConexao()) {
            System.out.println("Conexão obtida com sucesso!");
        } catch (Exception e) {
            System.out.println("Falha ao obter a conexão: " + e.getMessage());
        }
    }
}
