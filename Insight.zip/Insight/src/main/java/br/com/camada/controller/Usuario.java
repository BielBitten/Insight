
package br.com.camada.controller;

public class Usuario {
    
   private int id_usuario;
   private int id_tipo_ensino;
   private String nome;
   private String email;
   private String telefone;
   private String historicoDePerguntasRespondidas;
   private int tipoUsuario;

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_tipo_ensino() {
        return id_tipo_ensino;
    }

    public void setId_tipo_ensino(int id_tipo_ensino) {
        this.id_tipo_ensino = id_tipo_ensino;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getHistoricoDePerguntasRespondidas() {
        return historicoDePerguntasRespondidas;
    }

    public void setHistoricoDePerguntasRespondidas(String historicoDePerguntasRespondidas) {
        this.historicoDePerguntasRespondidas = historicoDePerguntasRespondidas;
    }

    public int getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(int tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
   
   
   public Usuario(){
   }
   
   
    
}
