package br.com.camada.dao;

import br.com.camada.controller.Usuario;
import br.com.camada.jdbc.ConnectFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {
    
    public Usuario obterUsuarioPorId (int idUsuario){
        Connection conexao = ConnectFactory.obterConexao();
        Usuario usuario = null;
        
        try {
            String sql = "SELECT * FROM Usuario WHERE id_usuario = ?";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, idUsuario);
                
         try (ResultSet resultado = stmt.executeQuery()) {
                    if (resultado.next()) {
                        usuario = mapearUsuario(resultado);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectFactory.fecharConexao(conexao);
        }

        return usuario;
    }

    private Usuario mapearUsuario(ResultSet resultado) throws SQLException {
        Usuario usuario = new Usuario();
        usuario.setId_usuario(resultado.getInt("id_usuario"));
        usuario.setId_tipo_ensino(resultado.getInt("id_tipo_ensino"));
        usuario.setNome(resultado.getString("nome"));
        usuario.setEmail(resultado.getString("email"));
        usuario.setTelefone(resultado.getString("telefone"));
        usuario.setHistoricoDePerguntasRespondidas(resultado.getString("historico_de_perguntas_respondidas"));
        usuario.setTipoUsuario(resultado.getInt("tipo_usuario"));

        return usuario;
    }
}