
package br.com.camada.controller;


public class Questao {
        private int id_pergunta;
    private int id_materia;
    private String texto_pergunta;
    private String resposta_1;
    private String resposta_2;
    private String resposta_3;
    private String resposta_4;
    private String resposta_5;

    public int getId_pergunta() {
        return id_pergunta;
    }

    public void setId_pergunta(int id_pergutna) {
        this.id_pergunta = id_pergutna;
    }

    public int getId_materia() {
        return id_materia;
    }

    public void setId_materia(int id_materia) {
        this.id_materia = id_materia;
    }

    public String getTexto_pergunta() {
        return texto_pergunta;
    }

    public void setTexto_pergunta(String texto_pergunta) {
        this.texto_pergunta = texto_pergunta;
    }

    public String getResposta_1() {
        return resposta_1;
    }

    public void setResposta_1(String resposta_1) {
        this.resposta_1 = resposta_1;
    }

    public String getResposta_2() {
        return resposta_2;
    }

    public void setResposta_2(String resposta_2) {
        this.resposta_2 = resposta_2;
    }

    public String getResposta_3() {
        return resposta_3;
    }

    public void setResposta_3(String resposta_3) {
        this.resposta_3 = resposta_3;
    }

    public String getResposta_4() {
        return resposta_4;
    }

    public void setResposta_4(String resposta_4) {
        this.resposta_4 = resposta_4;
    }

    public String getResposta_5() {
        return resposta_5;
    }

    public void setResposta_5(String resposta_5) {
        this.resposta_5 = resposta_5;
    }

    
}
