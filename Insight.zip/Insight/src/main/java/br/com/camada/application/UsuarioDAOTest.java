package br.com.camada.application;

import br.com.camada.controller.Usuario;
import br.com.camada.dao.UsuarioDAO;


public class UsuarioDAOTest {
    public static void main(String[] args) {
        testObterUsuarioPorId();
    }

    private static void testObterUsuarioPorId() {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        
       
        int idUsuario = 1;

        Usuario usuario = usuarioDAO.obterUsuarioPorId(idUsuario);

        if (usuario != null) {
            System.out.println("Usuário encontrado:");
            System.out.println("ID: " + usuario.getId_usuario());
            System.out.println("Nome: " + usuario.getNome());
            System.out.println("Email: " + usuario.getEmail());
           

        } else {
            System.out.println("Usuário não encontrado.");
        }
    }
}
   
