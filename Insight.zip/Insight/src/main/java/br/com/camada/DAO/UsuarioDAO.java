package br.com.camada.dao;

import br.com.camada.controller.Usuario;
import br.com.camada.jdbc.ConnectFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    public Usuario obterUsuarioPorId(int idUsuario) {
        try (Connection conexao = ConnectFactory.obterConexao()) {
            String sql = "SELECT * FROM Usuario WHERE id_usuario = ?";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, idUsuario);

                try (ResultSet resultado = stmt.executeQuery()) {
                    return resultado.next() ? mapearUsuario(resultado) : null;
                }
            }
        } catch (SQLException e) {
            // Trate a exceção apropriadamente, log ou relance se necessário
            throw new RuntimeException("Erro ao obter usuário por ID", e);
        }
    }

    public void cadastrarUsuario(Usuario novoUsuario) {
        try (Connection conexao = ConnectFactory.obterConexao()) {
            String sql = "INSERT INTO Usuario (id_tipo_ensino, nome, email, telefone, historico_de_perguntas_respondidas, tipo_usuario) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                preencherPreparedStatementComUsuario(stmt, novoUsuario);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao cadastrar usuário", e);
        }
    }

    public Usuario validarUsuario(String email, String senha) {
        try (Connection conexao = ConnectFactory.obterConexao()) {
            String sql = "SELECT * FROM Usuario WHERE email = ? AND senha = ?";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setString(1, email);
                stmt.setString(2, senha);

                try (ResultSet resultado = stmt.executeQuery()) {
                    return resultado.next() ? mapearUsuario(resultado) : null;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao validar usuário", e);
        }
    }

    private void preencherPreparedStatementComUsuario(PreparedStatement stmt, Usuario usuario) throws SQLException {
        stmt.setInt(1, usuario.getId_tipo_ensino());
        stmt.setString(2, usuario.getNome());
        stmt.setString(3, usuario.getEmail());
        stmt.setString(4, usuario.getTelefone());
        stmt.setString(5, usuario.getHistoricoDePerguntasRespondidas());
        stmt.setInt(6, usuario.getTipoUsuario());
    }

    private Usuario mapearUsuario(ResultSet resultado) throws SQLException {
        Usuario usuario = new Usuario();
        usuario.setId_usuario(resultado.getInt("id_usuario"));
        usuario.setId_tipo_ensino(resultado.getInt("id_tipo_ensino"));
        usuario.setNome(resultado.getString("nome"));
        usuario.setEmail(resultado.getString("email"));

        return usuario;
    }
    
    private static final Usuario USUARIO_LOCAL = new Usuario();

static {
    USUARIO_LOCAL.setNome("UsuarioLocal");
    USUARIO_LOCAL.setEmail("admin@admin.com");
    USUARIO_LOCAL.setSenha("admin");
   
}
    
    public Usuario validarUsuarioLocal(String email, String senha) {
        // Aqui você verifica se o email e senha correspondem a um usuário local
        // Por exemplo, você pode ter um usuário fixo com email "admin" e senha "admin123"
        if ("admin".equals(email) && "admin".equals(senha)) {
            Usuario usuario = new Usuario();
            usuario.setNome("Admin");
            usuario.setEmail("admin");
            // ... outros atributos
            return usuario;
        }
        return null; // Retorna null se as credenciais não forem válidas
    }
}

