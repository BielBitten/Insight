package br.com.camada.dao;

import br.com.principal.principal.insight.Insight;
import br.com.camada.controller.Questao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class QuestaoDAO {

    public List<Questao> obterQuestoesPorMateria(int idMateria) {
        List<Questao> questoes = new ArrayList<>();

        try (Connection conexao = Insight.obterConexao()) {
            String sql = "SELECT * FROM pergunta WHERE id_materia = ?";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, idMateria);

                try (ResultSet resultado = stmt.executeQuery()) {
                    while (resultado.next()) {
                        Questao questao = mapearQuestao(resultado);
                        questoes.add(questao);
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao obter questões por matéria", e);
        }

        return questoes;
    }


    private Questao mapearQuestao(ResultSet resultado) throws SQLException {
        Questao questao = new Questao();
        questao.setId_pergunta(resultado.getInt("id_pergunta"));
        questao.setId_materia(resultado.getInt("id_materia"));
        questao.setTexto_pergunta(resultado.getString("texto_pergunta"));
        questao.setResposta_1(resultado.getString("pergunta_1"));
        questao.setResposta_2(resultado.getString("pergunta_2"));
        questao.setResposta_3(resultado.getString("pergunta_3"));
        questao.setResposta_4(resultado.getString("pergunta_4"));
        questao.setResposta_5(resultado.getString("pergunta_5"));

        return questao;
    }

public Questao obterProximaQuestao(int idMateria, List<Integer> questoesRespondidas) {
    List<Questao> questoesNaoRespondidas = obterQuestoesNaoRespondidas(idMateria, questoesRespondidas);

    if (!questoesNaoRespondidas.isEmpty()) {
        return questoesNaoRespondidas.get(0);
    }

    return null;
}

    private List<Questao> obterQuestoesNaoRespondidas(int idMateria, List<Integer> questoesRespondidas) {
        List<Questao> todasQuestoes = obterQuestoesPorMateria(idMateria);
        List<Questao> naoRespondidas = new ArrayList<>();

        for (Questao questao : todasQuestoes) {
            if (!questoesRespondidas.contains(questao.getId_pergunta())) {
                naoRespondidas.add(questao);
            }
        }

        return naoRespondidas;
    }
    
    public int buscarAlternativaCorreta(int idQuestao) {
    
    String query = "SELECT resposta_correta FROM pergunta WHERE id_pergunta = ?";
    
    try (Connection connection = Insight.obterConexao();
         PreparedStatement preparedStatement = connection.prepareStatement(query)) {

        preparedStatement.setInt(1, idQuestao);

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt("resposta_correta");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Trate a exceção apropriadamente em um ambiente de produção
    }

    return -1; // Retorna -1 se não encontrar a alternativa correta (ajuste conforme necessário)
}
}

