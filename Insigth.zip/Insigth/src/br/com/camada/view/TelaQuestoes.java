/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.com.camada.view;

import br.com.camada.dao.UsuarioDAO;
import br.com.camada.controller.Questao;
import br.com.camada.dao.QuestaoDAO;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author gabri
 */
public class TelaQuestoes extends javax.swing.JFrame {
 private  int idMateria;
    private QuestaoDAO questaoDAO;
    private Questao questaoAtual;
    private List<Questao> questoesRespondidas;
    private int indiceQuestaoAtual;

    public TelaQuestoes(int idMateria,List<Questao> questoes ) {
        initComponents();
         this.idMateria = idMateria;  
    this.questaoDAO = new QuestaoDAO();
    this.questoesRespondidas = new ArrayList<>();
    setSize(400, 350);
    setLocationRelativeTo(null);
    }

     public TelaQuestoes(List<Questao> questoes) {
        initComponents();
        this.questaoDAO = new QuestaoDAO();
        this.questoesRespondidas = new ArrayList<>();
        setSize(400, 350);
        setLocationRelativeTo(null);

        // Adicione a lógica para exibir a primeira questão ao construir a tela
        if (questoes != null && !questoes.isEmpty()) {
            questaoAtual = questoes.get(0);
            atualizarComponentesComQuestao(questaoAtual);
        }
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        alternativa4 = new javax.swing.JRadioButton();
        alternativa1 = new javax.swing.JRadioButton();
        alternativa2 = new javax.swing.JRadioButton();
        alternativa3 = new javax.swing.JRadioButton();
        alternativa5 = new javax.swing.JRadioButton();
        txt_pergunta = new javax.swing.JTextField();
        btn_avancar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        alternativa4.setText("Alternativa 5");
        alternativa4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alternativa4ActionPerformed(evt);
            }
        });
        getContentPane().add(alternativa4);
        alternativa4.setBounds(20, 250, 290, 23);

        alternativa1.setText("Alternativa 1");
        alternativa1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alternativa1ActionPerformed(evt);
            }
        });
        getContentPane().add(alternativa1);
        alternativa1.setBounds(20, 100, 290, 23);

        alternativa2.setText("Alternativa 2");
        alternativa2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alternativa2ActionPerformed(evt);
            }
        });
        getContentPane().add(alternativa2);
        alternativa2.setBounds(20, 140, 300, 23);

        alternativa3.setText("Alternativa 3");
        alternativa3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alternativa3ActionPerformed(evt);
            }
        });
        getContentPane().add(alternativa3);
        alternativa3.setBounds(20, 180, 280, 23);

        alternativa5.setText("Alternativa 4");
        alternativa5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alternativa5ActionPerformed(evt);
            }
        });
        getContentPane().add(alternativa5);
        alternativa5.setBounds(20, 220, 310, 23);

        txt_pergunta.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(txt_pergunta);
        txt_pergunta.setBounds(10, 10, 380, 80);

        btn_avancar.setText("Avancar");
        btn_avancar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_avancar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_avancarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_avancar);
        btn_avancar.setBounds(310, 260, 80, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void alternativa1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alternativa1ActionPerformed
        
    }//GEN-LAST:event_alternativa1ActionPerformed

    private void alternativa2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alternativa2ActionPerformed
       
       
    }//GEN-LAST:event_alternativa2ActionPerformed

    private void alternativa3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alternativa3ActionPerformed
        
    }//GEN-LAST:event_alternativa3ActionPerformed

    private void alternativa5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alternativa5ActionPerformed
        
    }//GEN-LAST:event_alternativa5ActionPerformed

    private void alternativa4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alternativa4ActionPerformed
       
    }//GEN-LAST:event_alternativa4ActionPerformed

    private void btn_avancarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_avancarActionPerformed
         if (indiceQuestaoAtual < questoesRespondidas.size() - 1) {
        indiceQuestaoAtual++;
        questaoAtual = questoesRespondidas.get(indiceQuestaoAtual);
        atualizarComponentesComQuestao(questaoAtual);
    } else {
        // Aqui você pode lidar com o caso de não haver mais questões
        System.out.println("Não há mais questões disponíveis.");
    }
    }//GEN-LAST:event_btn_avancarActionPerformed

    private void atualizarComponentesComQuestao(Questao questao) {
        txt_pergunta.setText(questao.getTexto_pergunta());
        alternativa1.setText(questao.getResposta_1());
        alternativa2.setText(questao.getResposta_2());
        alternativa3.setText(questao.getResposta_3());
        alternativa4.setText(questao.getResposta_4());
        alternativa5.setText(questao.getResposta_5());
    }
    /**
     * @param args the command line arguments
     */
     public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaQuestoes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaQuestoes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaQuestoes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaQuestoes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
             public void run() {
            // Modifique esta chamada para passar uma lista de questões
            List<Questao> listaDeQuestoes = obterListaDeQuestoes(); // Substitua pelo método real
            new TelaQuestoes(listaDeQuestoes).setVisible(true);
        }

            private List<Questao> obterListaDeQuestoes() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
    });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton alternativa1;
    private javax.swing.JRadioButton alternativa2;
    private javax.swing.JRadioButton alternativa3;
    private javax.swing.JRadioButton alternativa4;
    private javax.swing.JRadioButton alternativa5;
    private javax.swing.JButton btn_avancar;
    private javax.swing.JTextField txt_pergunta;
    // End of variables declaration//GEN-END:variables
}
