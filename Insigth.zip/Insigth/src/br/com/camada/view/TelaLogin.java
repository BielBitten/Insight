/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.com.camada.view;

import br.com.camada.controller.Usuario;
import br.com.camada.dao.UsuarioDAO;
import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author gabri
 */
public class TelaLogin extends javax.swing.JFrame {

   private UsuarioDAO usuarioDAO;

    /**
     * Creates new form TelaLogin
     */
    public TelaLogin() {
        initComponents();
        usuarioDAO = new UsuarioDAO();
    setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    
     
        setSize(400, 350);
        
       
        setLocationRelativeTo(null);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_boasVindas = new javax.swing.JLabel();
        lbl_senha = new javax.swing.JLabel();
        lbl_email = new javax.swing.JLabel();
        txt_email = new javax.swing.JTextField();
        btn_sair = new javax.swing.JButton();
        btn_cadastro = new javax.swing.JButton();
        btn_avancar = new javax.swing.JButton();
        txt_senha = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lbl_boasVindas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_boasVindas.setText("Bem vindo ao Insight, the game of year!");
        lbl_boasVindas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(lbl_boasVindas);
        lbl_boasVindas.setBounds(12, 12, 376, 75);

        lbl_senha.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_senha.setText("Senha");
        getContentPane().add(lbl_senha);
        lbl_senha.setBounds(20, 150, 50, 30);

        lbl_email.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_email.setText("Email");
        getContentPane().add(lbl_email);
        lbl_email.setBounds(20, 90, 50, 40);
        getContentPane().add(txt_email);
        txt_email.setBounds(80, 110, 220, 20);

        btn_sair.setText("Sair");
        btn_sair.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sairActionPerformed(evt);
            }
        });
        getContentPane().add(btn_sair);
        btn_sair.setBounds(10, 240, 110, 40);

        btn_cadastro.setText("Cadastro");
        btn_cadastro.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_cadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cadastroActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cadastro);
        btn_cadastro.setBounds(140, 240, 110, 40);

        btn_avancar.setText("Avancar");
        btn_avancar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_avancar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_avancarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_avancar);
        btn_avancar.setBounds(270, 240, 110, 40);

        txt_senha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_senhaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_senha);
        txt_senha.setBounds(80, 150, 220, 20);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_avancarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_avancarActionPerformed
         String email = txt_email.getText();
    char[] senhaChars = txt_senha.getPassword();
    String senha = new String(senhaChars);
    
    Arrays.fill(senhaChars, '0');

    Usuario usuarioLocal = usuarioDAO.validarUsuarioLocal(email, senha);

    if (usuarioLocal != null) {
        // Abrir a TelaDeMenu
        TelaDeMenu telaMenu = new TelaDeMenu();
        telaMenu.setVisible(true);

        
        this.dispose();
    } else {
        
        Usuario usuario = usuarioDAO.validarUsuario(email, senha);

        if (usuario != null) {
            // Abrir a TelaDeMenu em vez da TelaDeCadastro
            TelaDeMenu telaMenu = new TelaDeMenu();
            telaMenu.setVisible(true);

            // Fechar a tela de login
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Usuário inexistente ou senha incorreta. Verifique suas credenciais.");
        }
    }


    }//GEN-LAST:event_btn_avancarActionPerformed

    private void btn_cadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cadastroActionPerformed
        TelaDeCadastro telaCadastro = new TelaDeCadastro();
        telaCadastro.setVisible(true);

        
        this.dispose(); 
    }//GEN-LAST:event_btn_cadastroActionPerformed

    private void btn_sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_sairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btn_sairActionPerformed

    private void txt_senhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_senhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_senhaActionPerformed

    /**
     * @param args the command line arguments
     */
   public static void main(String args[]) {
       
    try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    } catch (ClassNotFoundException ex) {
        java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (InstantiationException ex) {
        java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (IllegalAccessException ex) {
        java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (javax.swing.UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_avancar;
    private javax.swing.JButton btn_cadastro;
    private javax.swing.JButton btn_sair;
    private javax.swing.JLabel lbl_boasVindas;
    private javax.swing.JLabel lbl_email;
    private javax.swing.JLabel lbl_senha;
    private javax.swing.JTextField txt_email;
    private javax.swing.JPasswordField txt_senha;
    // End of variables declaration//GEN-END:variables
private Usuario validarUsuarioLocal(String email, String senha) {
        
        return email.equals("usuario_local") && senha.equals("senha_local") ? new Usuario() : null;
    }
}

