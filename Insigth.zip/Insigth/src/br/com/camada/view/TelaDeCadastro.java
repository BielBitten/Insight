/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.com.camada.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author gabri
 */
public class TelaDeCadastro extends javax.swing.JFrame {

    public TelaDeCadastro() {
        initComponents();
        btn_avancar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                realizarCadastro();
            }
        });
        
        setSize(500, 450);
        
        
        setLocationRelativeTo(null);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        lbl_email = new javax.swing.JLabel();
        lbl_nome = new javax.swing.JLabel();
        lbl_senha = new javax.swing.JLabel();
        lbl_telefone = new javax.swing.JLabel();
        txt_email = new javax.swing.JTextField();
        txt_nome_completo = new javax.swing.JTextField();
        txt_telefone = new javax.swing.JTextField();
        ckx_ensino_medio = new javax.swing.JCheckBox();
        ckx_fund1 = new javax.swing.JCheckBox();
        ckx_fund2 = new javax.swing.JCheckBox();
        btn_avancar = new javax.swing.JButton();
        txt_senha = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Cadastro");
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 10, 460, 90);

        lbl_email.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_email.setText("Email");
        getContentPane().add(lbl_email);
        lbl_email.setBounds(270, 100, 200, 40);

        lbl_nome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_nome.setText("Nome");
        getContentPane().add(lbl_nome);
        lbl_nome.setBounds(10, 100, 200, 40);

        lbl_senha.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_senha.setText("Senha");
        getContentPane().add(lbl_senha);
        lbl_senha.setBounds(270, 170, 200, 30);

        lbl_telefone.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_telefone.setText("Telefone");
        getContentPane().add(lbl_telefone);
        lbl_telefone.setBounds(10, 170, 200, 30);

        txt_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_emailActionPerformed(evt);
            }
        });
        getContentPane().add(txt_email);
        txt_email.setBounds(270, 140, 200, 30);

        txt_nome_completo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nome_completoActionPerformed(evt);
            }
        });
        getContentPane().add(txt_nome_completo);
        txt_nome_completo.setBounds(10, 140, 200, 30);

        txt_telefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_telefoneActionPerformed(evt);
            }
        });
        getContentPane().add(txt_telefone);
        txt_telefone.setBounds(10, 200, 200, 30);

        ckx_ensino_medio.setText("Ensino medio");
        ckx_ensino_medio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ckx_ensino_medioActionPerformed(evt);
            }
        });
        getContentPane().add(ckx_ensino_medio);
        ckx_ensino_medio.setBounds(20, 300, 170, 23);

        ckx_fund1.setText("Fundamental l");
        ckx_fund1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ckx_fund1ActionPerformed(evt);
            }
        });
        getContentPane().add(ckx_fund1);
        ckx_fund1.setBounds(20, 240, 170, 23);

        ckx_fund2.setText("Fundamental ll");
        ckx_fund2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ckx_fund2ActionPerformed(evt);
            }
        });
        getContentPane().add(ckx_fund2);
        ckx_fund2.setBounds(20, 270, 170, 23);

        btn_avancar.setText("Avancar");
        btn_avancar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_avancar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_avancarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_avancar);
        btn_avancar.setBounds(340, 280, 120, 40);

        txt_senha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_senhaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_senha);
        txt_senha.setBounds(270, 200, 200, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailActionPerformed

    private void txt_nome_completoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nome_completoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nome_completoActionPerformed

    private void txt_telefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_telefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_telefoneActionPerformed

    private void btn_avancarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_avancarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_avancarActionPerformed

    private void ckx_ensino_medioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ckx_ensino_medioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ckx_ensino_medioActionPerformed

    private void ckx_fund2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ckx_fund2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ckx_fund2ActionPerformed

    private void ckx_fund1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ckx_fund1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ckx_fund1ActionPerformed

    private void txt_senhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_senhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_senhaActionPerformed

   private void realizarCadastro() {
    String nome = txt_nome_completo.getText();
    String email = txt_email.getText();
    String telefone = txt_telefone.getText();
    String senha = new String(txt_senha.getPassword());

   
    if (nome.isEmpty() || email.isEmpty() || telefone.isEmpty() || senha.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

  
    int id_tipo_ensino = 0;
    if (ckx_fund1.isSelected()) {
        id_tipo_ensino = 1;
    } else if (ckx_fund2.isSelected()) {
        id_tipo_ensino = 2;
    } else if (ckx_ensino_medio.isSelected()) {
        id_tipo_ensino = 3;
    }

   
    try (Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_insight", "root", "Gabi2801!")) {
        if (!verificarTipoEnsinoExistente(conexao, id_tipo_ensino)) {
            // Se o tipo de ensino não existe, insere na tabela TipoEnsino
            if (!inserirTipoEnsino(conexao, id_tipo_ensino)) {
                System.out.println("Erro ao inserir tipo de ensino na tabela TipoEnsino.");
                return;
            }
        }

        
        String sql = "INSERT INTO usuario (id_tipo_ensino, nome, email, senha, telefone, tipo_usuario) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id_tipo_ensino);
            stmt.setString(2, nome);
            stmt.setString(3, email);
            stmt.setString(4, senha);
            stmt.setString(5, telefone);
            stmt.setInt(6, 1); // Aqui você definiu o valor 1 para tipo_usuario (usuário normal)
            stmt.executeUpdate();
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Erro ao inserir dados no banco de dados: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

   
    txt_nome_completo.setText("");
    txt_email.setText("");
    txt_telefone.setText("");
    txt_senha.setText("");

   
    TelaLogin telaLogin = new TelaLogin();
    telaLogin.setVisible(true);
    this.dispose(); // Fecha a tela atual
}

private boolean verificarTipoEnsinoExistente(Connection conexao, int id_tipo_ensino) {
    String sql = "SELECT * FROM tipoensino WHERE id_tipo_ensino = ?";
    try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
        stmt.setInt(1, id_tipo_ensino);
        try (var rs = stmt.executeQuery()) {
            return rs.next();
        } catch (SQLException ex) {
            System.err.println("Erro ao executar a consulta do ResultSet: " + ex.getMessage());
            return false;
        }
    } catch (SQLException ex) {
        System.err.println("Erro ao preparar a declaração SQL: " + ex.getMessage());
        return false;
    }
}

private boolean inserirTipoEnsino(Connection conexao, int id_tipo_ensino) {
    String sql = "INSERT INTO tipoensino (id_tipo_ensino, nome_ensino) VALUES (?, ?)";
    try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
        stmt.setInt(1, id_tipo_ensino);
        // Se tiver um nome associado ao tipo de ensino, ajuste o valor abaixo
        stmt.setString(2, "Nome do tipo de ensino");
        stmt.executeUpdate();
        return true; // Inserção bem-sucedida
    } catch (SQLException ex) {
        System.err.println("Erro ao inserir tipo de ensino: " + ex.getMessage());
        return false;
    }
}


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaDeCadastro().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_avancar;
    private javax.swing.JCheckBox ckx_ensino_medio;
    private javax.swing.JCheckBox ckx_fund1;
    private javax.swing.JCheckBox ckx_fund2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lbl_email;
    private javax.swing.JLabel lbl_nome;
    private javax.swing.JLabel lbl_senha;
    private javax.swing.JLabel lbl_telefone;
    private javax.swing.JTextField txt_email;
    private javax.swing.JTextField txt_nome_completo;
    private javax.swing.JPasswordField txt_senha;
    private javax.swing.JTextField txt_telefone;
    // End of variables declaration//GEN-END:variables
}
