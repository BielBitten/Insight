package br.com.principal.principal.insight;

import br.com.camada.controller.Questao;
import br.com.camada.controller.Usuario;
import br.com.camada.dao.QuestaoDAO;
import br.com.camada.dao.UsuarioDAO;
import br.com.camada.view.TelaLogin;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Insight {

    private static final String URL = "jdbc:mysql://localhost:3306/bd_insight";
    private static final String USUARIO = "root";
    private static final String SENHA = "Gabi2801!";

    public static Connection obterConexao() {
        try {
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (SQLException ex) {
            Logger.getLogger(Insight.class.getName()).log(Level.SEVERE, "Erro ao obter conexão com o banco de dados", ex);
            throw new RuntimeException("Erro ao obter conexão com o banco de dados", ex);
        }
    }

    public static void main(String[] args) {
        
        Connection con = obterConexao();
        System.out.println("Conexão estabelecida");

       
        java.awt.EventQueue.invokeLater(() -> {
            new TelaLogin().setVisible(true);
        });

       
        QuestaoDAO questaoDAO = new QuestaoDAO();
        int idMateria = 1; 
        List<Questao> questoes = questaoDAO.obterQuestoesPorMateria(idMateria);
        for (Questao questao : questoes) {
            System.out.println(questao.getTexto_pergunta());
        }

        
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        int idUsuario = 1; 
        Usuario usuario = usuarioDAO.obterUsuarioPorId(idUsuario);
        if (usuario != null) {
            System.out.println("Usuário encontrado: " + usuario.getNome());
        } else {
            System.out.println("Usuário não encontrado");
        }
    }
}
